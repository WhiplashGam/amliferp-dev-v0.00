INSERT INTO `items` (name, label, `limit`) VALUES
	('weed', 'Weed', 50),
	('weed_pooch', 'Pochon de weed', 10),
	('coke', 'Coke', 50),
	('coke_pooch', 'Pochon de coke', 10),
	('meth', 'Meth', 50),
	('meth_pooch', 'Pochon de meth', 10),
	('opium', 'Opium', 50),
	('opium_pooch', 'Pochon de opium', 10)
;