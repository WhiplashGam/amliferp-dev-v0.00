INSERT INTO `items` (name, label, `limit`) VALUES
	('weed', 'Grass', 50),
	('weed_pooch', 'Portion Grass', 10),
	('coke', 'Koks', 50),
	('coke_pooch', 'Portion Koks', 10),
	('meth', 'Meth', 50),
	('meth_pooch', 'Portion Meth', 10),
	('opium', 'Opium', 50),
	('opium_pooch', 'Portion Opium', 10)
;