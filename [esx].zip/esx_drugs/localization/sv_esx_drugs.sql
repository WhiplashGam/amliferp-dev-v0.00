INSERT INTO `items` (name, label, `limit`) VALUES
	('weed', 'Cannabis', 50),
	('weed_pooch', 'Väska med cannabis', 10),
	('coke', 'Kokain', 50),
	('coke_pooch', 'Väska med kokain', 10),
	('meth', 'Meth', 50),
	('meth_pooch', 'Väska med meth', 10),
	('opium', 'Opium', 50),
	('opium_pooch', 'Väska med opium', 10)
;
