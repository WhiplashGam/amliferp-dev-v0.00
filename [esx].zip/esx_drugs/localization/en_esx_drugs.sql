INSERT INTO `items` (name, label, `limit`) VALUES
	('weed', 'Weed', 50),
	('weed_pooch', 'Bag of weed', 10),
	('coke', 'Cocaine', 50),
	('coke_pooch', 'Bag of cocaine', 10),
	('meth', 'Meth', 50),
	('meth_pooch', 'Bag of meth', 10),
	('opium', 'Opium', 50),
	('opium_pooch', 'Bag of opium', 10)
;
