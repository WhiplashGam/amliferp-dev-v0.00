Config = {}
Config.Locale = 'fr'
Config.NumberOfCopsRequired = 5

Banks = {
	["fleeca"] = {
		position = { ['x'] = 1175.89, ['y'] = 2711.57, ['z'] = 38.00 },
		reward = math.random(15000,25000),
		nameofbank = "Fleeca Bank Grand Senora",
		lastrobbed = 0
	},
	["24/7 grapessed"] = {
		position = { ['x'] = 1707.83, ['y'] = 4920.47, ['z'] = 42.06 },
		reward = math.random(15000,25000),
		nameofbank = "Grapessed 24/7",
		lastrobbed = 0
	},
	["24/7 paletobay"] = {
		position = { ['x'] = 168.94, ['y'] = 6644.80, ['z'] = 31.71 },
		reward = math.random(15000,25000),
		nameofbank = "Paleto Bay 24/7",
		lastrobbed = 0
	},
	["blainecounty"] = {
		position = { ['x'] = -107.06505584717, ['y'] = 6474.8012695313, ['z'] = 31.62670135498 },
		reward = math.random(15000,25000),
		nameofbank = "Blaine County Savings",
		lastrobbed = 0
	}
}