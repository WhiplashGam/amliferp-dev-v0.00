Config = {}
Config.Locale = 'fr'
Config.NumberOfCopsRequired = 5

Banks = {
	["fleeca"] = {
		position = { ['x'] = 147.04908752441, ['y'] = -1044.9448242188, ['z'] = 29.36802482605 },
		reward = math.random(15000,25000),
		nameofbank = "Fleeca Bank (Vespucci)",
		lastrobbed = 0
	},
	["fleeca2"] = {
		position = { ['x'] = -2957.6674804688, ['y'] = 481.45776367188, ['z'] = 15.697026252747 },
		reward = math.random(15000,25000),
		nameofbank = "Fleeca Bank (Highway)",
		lastrobbed = 0
	},	
	["fleeca3"] = {
		position = { ['x'] = 311.58, ['y'] = -283.79, ['z'] = 54.16 },
		reward = math.random(15000,25000),
		nameofbank = "Fleeca Bank (Hawick Avenue)",
		lastrobbed = 0
	},
	["PacificalBank"] = {
		position = { ['x'] = 255.001098632813, ['y'] = 225.855895996094, ['z'] = 101.005694274902 },
		reward = math.random(20000,30000),
		nameofbank = "Pacifica bank",
		lastrobbed = 0
	}
}