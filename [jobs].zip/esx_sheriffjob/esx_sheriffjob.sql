INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_sheriff', 'sheriff', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_sheriff', 'sheriff', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_sheriff', 'sheriff', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('sheriff','BCSO')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('sheriff',0,'deputy','Deputy',10,'{}','{}'),
	('sheriff',1,'deputy1','Deputy 1° Classe',20,'{}','{}'),
	('sheriff',2,'caporal','Caporal',30,'{}','{}'),
	('sheriff',3,'sergent','Sergent',40,'{}','{}'),
	('sheriff',4,'lieutenant','Lieutenant',50,'{}','{}'),
	('sheriff',5,'capitaine','Capitaine',60,'{}','{}'),
	('sheriff',6,'chef','sheriff-Adjoint',70,'{}','{}'),
	('sheriff',7,'boss','sheriff',80,'{}','{}')
;

CREATE TABLE `fine_types` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`label` varchar(255) DEFAULT NULL,
	`amount` int(11) DEFAULT NULL,
	`category` int(11) DEFAULT NULL,

	PRIMARY KEY (`id`)
);

INSERT INTO `fine_types` (label, amount, category) VALUES
	('Circulation Dangereuse',200,0),
	('Défaut de vitre avant',500,0),
	('Défaut de vitre arrière',500,0),
	('Défaut de feu arrière ',900,0),
	('Défaut de feu avant ',900,0),
	('Excès de vitesse de -50 km/h',1000,0),
	('Excès de vitesse de +50 km/h',1200,0),
	('Non-respect de priorité d un véhicule prioritaire',2000,0),
	('Non port du casque en étant sur un 2 roue',2500,0),
	('Conduite sans Permis',6000,0),
	('Insulte sur la voie publique',250,1),
	('Atteinte à la pudeur',600,1),
	('Exhibition sur la voie publique',800,1),
	('Insulte sur un représentant de la ville',1500,1),
	('Ivresse sur la voie publique',1800,1),
	('Ivresse au volant',2000,1),
	('Conduite sous l emprise de stupéfiant',3000,1),
	('Conduite sous l emprise d alcool',3000,1),
	('Rixe sur la voie publique',4000,1),
	('Tentative d émeute ',5000,1),	
	('Agression sur la voie publique',2600,2),
	('Agression sur un personnel médicale',8500,2),
	('harcèlement',5000,2),
	('Menace de Mort',8000,2),
	('Tentative de kidnapping',20000,2),
	('Tentative de vole ',15000,2),
	('Tentative de vole de véhicule',18000,2),
	('Tentative de meurtre sur un individue',28000,2),
	('Vole sur un individue',25000,2),
	('vole de véhicule',30000,2),
	('Récolte de drogue',40000,2),
	('Transformation de drogue',40500,2),
	('Vente de drogue',40800,2),	
	('Braquage de banque',50000,3),
	('Braquage de la Brinks',70000,3),
	('Braquage Banque Fédérale',80000,3),
	('Chef de Gang/ / Trafiquant divers',90000,3),
	('Attaque Terroriste',100000,3),
	('Meurtres sur civile',150000,3),
	('Meurtres sur un membre des Forces de L ordre',200000,3),
	('Meurtres sur un membre du Bureaux du Procureur',250000,3),
	('Meurtres sur un membre de gouvernement',300000,3),
	('Meurtre sur le Gouverneur',600000,3)

;

