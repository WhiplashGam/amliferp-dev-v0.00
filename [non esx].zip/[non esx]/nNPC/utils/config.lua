Config = { 
    Locations = {
        [1] = { --GOOD
            ["myPedsLocation"] = {
                ["x"] = 458.98, ["y"] = -1017.25, ["z"] =28.16, ["h"] = 95.0,
                ["hash"] = 1581098148,
                ["anim_dict"] = "anim@amb@nightclub@peds@",
                ["anim_action"] = "amb_world_human_cheering_female_c"
            },
        },

        [2] = { --GOOD
            ["myPedsLocation"] = {
                ["x"] = -478.67, ["y"] = 6014.74, ["z"] =31.34, ["h"] = 300.0,
                ["hash"] = -1320879687,
                ["anim_dict"] = "anim@amb@nightclub@peds@",
                ["anim_action"] = "amb_world_human_cheering_female_c"
            },
        },

        --[[[3] = { --GOOD
        ["myPedsLocation"] = {
            ["x"] = 443.17, ["y"] = -1015.15, ["z"] =28.63, ["h"] = 180.0,
            ["hash"] = -1782092083,
            ["anim_dict"] = "anim@amb@nightclub@peds@",
            ["anim_action"] = "amb_world_human_cheering_female_c"
        },]]  

        
    },
}