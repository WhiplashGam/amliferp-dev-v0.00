Config = {}


Config.Vehicles = {
    {Label = "CVPI Sheriff",              Hash = "sheriff"},
    {Label = "Ford Interceptor",           Hash = "sheriff2"},
    {Label = "Harley Sheriff",                 Hash = "pdbike"},
    {Label = "CVPI Unmarked",                 Hash = "sheriffoss"},
    
}