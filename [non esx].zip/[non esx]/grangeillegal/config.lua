Config = {}

Config.ArgentSale = false

Config.Weapons = {
    {weapon = "weapon_snspistol", price = 5000},
    {weapon = "weapon_pistol", price = 5500},
    {weapon = "weapon_pistol50", price = 6000},
    {weapon = "weapon_machinepistol", price = 8000},
    {weapon = "weapon_minismg", price = 9000},
    {weapon = "weapon_assaultrifle", price = 11000},
    {weapon = "weapon_compactrifle", price = 12000},    

}

--Liste des armes : https://wiki.rage.mp/index.php?title=Weapons

----------------------------------------
--Dev by Thom512#0990 for Patoche#4702--
----------------------------------------
