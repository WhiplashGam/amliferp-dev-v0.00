# qalle-wheelchair

[NOTES]

* Gives you the opportunity to have people in the wheelchair or you can drive the wheelchair yourself very slow (you can change the speed in the client)

* I made this a long time ago and got no use for it, if someone here to make it better go ahead.

* You spawn it with /wheelchair.

[REQUIREMENTS]
  
* None, standalone

[INSTALLATION]

1) Download: https://github.com/qalle-fivem/qalle-wheelchair

2) Add this in your server.cfg :
``start qalle-wheelchair``

[TODO]

* Checks if someone else is in the wheelchair / holding the wheelchair
* Fix rotations when sitting (im lazy)

[SCREENSHOTS]

![ladda%20ned|616x500](upload://oAKLiYIDSLZOXQ6O7yhRFtw94AC.jpeg)![ladda%20ned%20(1)|505x500](upload://43C8i1z4tEd2g0FpHxWdKZ12ynl.png)
