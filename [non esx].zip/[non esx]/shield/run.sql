USE `essentialmode`;


INSERT INTO `items` (`name`, `label`, `limit`) VALUES
  ('shield', 'Police Shield', 2)

;
