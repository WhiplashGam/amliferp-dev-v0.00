# RichPresence

Vous pouvez télécharger directement RichPresence, en remplissant les données de votre RichPresence Discord déja crée auparavant.

Mettre dans vos ressources

start RichPresence , dans votre server.cfg
