--BY BNJ-- 𝑯𝒐𝒎𝒎𝒆-𝒆𝒇𝒇𝒊𝒄𝒂𝒔𝒆
Config = {
	czas = 600, -- Temps après lequel la plaque peut être de nouveau vu (minutes)
	cooldown = 30, -- Temps d'attente pour changer de nouveau la plaque
	money = 50000, -- Prix de changement	
	coords = { x = 995.9, y = -1557.1, z = 30.75 }, -- Coordonnées de l'atelier
	coords = { x = 1339.66, y = 4315.38, z = 37.97 },-- Coordonnées de l'atelier

	-- Blip (https://docs.fivem.net/game-references/blips/)
	blipEnabled =false, -- Le blip doit-il être affiché sur la carte?
	blipSprite = 402,
	blipColour = 40,
	blipScale = 0.8,
	blipName = 'Supression de plaque',
	
	-- Ped (https://wiki.rage.mp/index.php?title=Peds)
	pedName = 'mp_m_waremech_01',
	pedHash = 0xF7A74139,
	pedHeading = -90.0,
	pedCoords = { x = 995.9, y = -1557.1, z = 30.75 },
	pedCoords = { x = 1336.86, y = 4311.67, z = 37.99 },
}

