#####################################################
                      Frensh
#####################################################

--BY BNJ-- 𝑯𝒐𝒎𝒎𝒆-𝒆𝒇𝒇𝒊𝒄𝒂𝒔𝒆

Installation : Mettre dans vos resources/ Mettre le SQL et start dans server.cfg
________________________________________________________________________________

Requirements :

InteractSound


#####################################################
                      English
#####################################################

--BY BNJ-- 𝑯𝒐𝒎𝒎𝒆-𝒆𝒇𝒇𝒊𝒄𝒂𝒔𝒆

Installation: Put in your resources / Put the SQL and start in server.cfg
________________________________________________________________________________

Requirements:

InteractSound
