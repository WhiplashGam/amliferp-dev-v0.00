---
name: Feature request
about: Suggest a feature or improvement for the resource
title: "[SUGGESTION]"
labels: enhancement
assignees: ''

---

**What is your suggestion?**
Describe your suggestion in detail.
