Config = { 
    Locations = {
        [1] = { --GOOD
            ["myPedsLocation"] = {
                ["x"] = -5.03, ["y"] = -663.67, ["z"] =32.33, ["h"] = 180.0,
                ["hash"] =  -1782092083,
                ["anim_dict"] = "anim@amb@nightclub@peds@",
                ["anim_action"] = "amb_world_human_cheering_female_c"
            },
        },

        [2] = { --GOOD
            ["myPedsLocation"] = {
                ["x"] = 321.77, ["y"] = -559.12, ["z"] =28.74, ["h"] = 30.0,
                ["hash"] = -730659924,
                ["anim_dict"] = "anim@amb@nightclub@peds@",
                ["anim_action"] = "amb_world_human_cheering_female_c"
            },
        },

        --[[[3] = { --GOOD
        ["myPedsLocation"] = {
            ["x"] = 440.283, ["y"] = -1014.85, ["z"] =28.6427, ["h"] = 180.0, --Your Location.
            ["hash"] = "a_f_m_bodybuild_01", --Your Peds Hash.
            ["anim_dict"] = "anim@amb@nightclub@peds@", --Your Anim Dict.
            ["anim_action"] = "amb_world_human_cheering_female_c" --Your Anim Action.
        },]]
    },
}