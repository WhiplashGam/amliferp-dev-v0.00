# InteractNPCLocation
Adds NPCs to various venues such as markets, clothing stores, armories and more. An NPC animation is also added (default arms crossed)

### Installation:
- Enter the script folder of your resource folder
- Start the `InteractNPCLocation` resource in .cfg file

### Support
[![Discord](https://i.imgur.com/9GFVWqX.png)](https://discord.gg/Ev9WBKy) [![Telegram](https://i.imgur.com/RcZ4ALP.png)](https://t.me/Dracke)

### Image

![Imgur](https://i.imgur.com/YS8Vv2K.png)

![Imgur](https://i.imgur.com/fY2PCFh.png)

![Imgur](https://i.imgur.com/fMLcxdt.png)

## Changelog:
- Fixed start resource bug (04/03/2020)
