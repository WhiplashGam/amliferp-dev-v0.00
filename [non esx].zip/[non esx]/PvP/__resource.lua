description 'Activates PvP'

client_script 'PvP.lua'