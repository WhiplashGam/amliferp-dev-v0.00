# FiveM - heli by mraes
Version 1.3 - 2017/06/09

Instructions:
 * Download resource
 * Add heli entry to your citmp-server.yml AutoStartResources
 * Press the the E key to switch to the HeliCam
 * Whilst in Helicam: move mouse to rotate cam, scroll to zoom and use the RIGHT MOUSE BUTTON to switch between normal, nightvision and thermal vision
 * Whilst in Helicam: when hovering over a vehicle and close enough to it, you can see vehicle info. If you can see this, press SPACE to lock camera onto the vehicle. SPACE again to unlock camera.
 * Press the X key to rappel from the helicopter
 * Press the G key as helicopter pilot to switch on the spotlight (this is synced across the network to all players)
 
 Changelog:
 * 2017/06/08: Added smoothing to camera movement.
 * 2017/06/08: Added Nightvision and Thermal Vision.
 * 2017/06/09: Made camera movement smoother when zoomed in.
 * 2017/06/12: Added rappel, spotlight and showing of vehicle information + lock onto vehicle. Changed some keys. Added screen effect overlay to make it look like cam feed.