# ChairBedSystem

<html>
<h3>What do this script do?</h3>
<p>This script will let you sit or lay on a bed, chair or what ever you want:P
<br>There is an easy config in the client.lua, where you can add/remove objects.</p>
<h3>Requirements?</h3>
<p>- None</p>
<h3>Video</h3>
<p>Click on the video below!</p>

<a href="https://streamable.com/doa1q" target="_blank">
<img src="https://i.gyazo.com/16da4dc3bfb0e82814247729c9e4332d.jpg" 
alt="IMAGE ALT TEXT HERE" width="540" height="280" border="10" /></a>


<br>
<h3>Other Releases</h3>
<p><b>- Radargun (<a href="https://github.com/TerbSEC/Radargun" target="_blank">Github</a> / <a href="https://forum.fivem.net/t/release-radargun-laser-gun-v1-1-huge-improvements-and-new-ui/179682" target="_blank">FiveM Forum</a>)
<br>- Healthbar / UI (<a href="https://github.com/TerbSEC/HealthbarUI" target="_blank">Github</a> / <a href="https://forum.fivem.net/t/discontinued-healthbar-ui-now-supports-vrp-and-esx-v-1-1/265693" target="_blank">FiveM Forum</a>)
<br>- Coords Pack (<a href="https://github.com/TerbSEC/FiveM-CoordsSaver" target="_blank">Github</a> / <a href="https://forum.fivem.net/t/release-coords-pack-include-copy-coords-to-clipboard-and-tpc/747132" target="_blank">FiveM Forum</a>)

</html>