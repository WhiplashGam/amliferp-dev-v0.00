client_scripts {
    "c.js",
}