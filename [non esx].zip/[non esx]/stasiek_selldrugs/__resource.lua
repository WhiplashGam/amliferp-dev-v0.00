resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

server_scripts {
	'@es_extended/locale.lua',
	'locales/pl.lua',
	'locales/en.lua',
	'locales/it.lua',
	'locales/fr.lua',
	'locales/sv.lua',
	'locales/nl.lua',
	'server/main.lua',
	'config.lua'
}

client_scripts {
	'@es_extended/locale.lua',
	'locales/pl.lua',
	'locales/en.lua',
	'locales/it.lua',
	'locales/fr.lua',
	'locales/sv.lua',
	'locales/nl.lua',
	'client/main.lua',
	'config.lua'
}