# eden_accesories
weapon accesories for esx


[INSTALLATION]

1) CD in your resources/[esx] folder
2) Clone the repository
```
git clone https://github.com/ESX-PUBLIC/eden_accesories.git eden_accesories
```
3) Import eden_weapon_accesories.sql in your database
4) Add this in your server.cfg :

```
start eden_accesories
```

5) Add a place where people can buy these items

This script need an English translate, if you made one pm me on discord at Solaris#6632
