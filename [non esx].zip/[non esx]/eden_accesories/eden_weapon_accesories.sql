INSERT INTO `items` (`id`, `name`, `label`, `weight`, `rare`, `can_remove`) VALUES (2010, 'yusuf', 'Skin de luxe', 1, 0, 1);
INSERT INTO `items` (`id`, `name`, `label`, `weight`, `rare`, `can_remove`) VALUES (209, 'grip', 'Poignée', 1, 0, 1);
INSERT INTO `items` (`id`, `name`, `label`, `weight`, `rare`, `can_remove`) VALUES (208, 'flashlight', 'Lampe', 1, 0, 1);
INSERT INTO `items` (`id`, `name`, `label`, `weight`, `rare`, `can_remove`) VALUES (207, 'silencieux', 'Silencieux', 1, 0, 1);
