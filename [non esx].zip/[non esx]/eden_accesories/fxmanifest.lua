fx_version 'adamant'

game 'gta5'

description 'Eden Weapon Accesories'

server_scripts {
	'config.lua',
	'server/main.lua',
}

client_scripts {
	'config.lua',
	'client/main.lua'
}
