Config = {}


Config.Vehicles = {
    {Label = "Police Cruiser",              Hash = "police"},
    {Label = "Buffalo de police",           Hash = "police2"},
    {Label = "Interceptor",                 Hash = "police3"},
    {Label = "Police cruiser Unmarked",     Hash = "police4"},
    {Label = "Buffalo Unmarked",            Hash = "fbi"},
    {Label = "SUV Unmarked",                Hash = "fbi2"},
    {Label = "Oracle police",               Hash = "sheriff"},
    {Label = "SUV Sheriff",                 Hash = "sheriff2"},
    {Label = "Moto de police",              Hash = "policeb"},
    {Label = "Fourgon de transport",        Hash = "policet"},
    {Label = "Blinder LSPD",                Hash = "riot"},
    {Label = "Fourgon antiémeute",          Hash = "riot2"},
    {Label = "~r~Vehicule de formation",    Hash = "sultan"},
}