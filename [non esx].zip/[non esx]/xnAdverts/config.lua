Config = {}

Config.AllAds = {
--  ["What you'll type in chat"] = {'Texture Dictionary', 'Texture Name', 'Ad Title', 'Ad Subtitle (Optional)'},
	["247"] 		= {'custom_adverts', '247', '24/7 Shop'},
	["ammunation"] 	= {'CHAR_AMMUNATION', 'CHAR_AMMUNATION', 'Ammunation'},
	["bank"] 		= {'CHAR_BANK_FLEECA', 'CHAR_BANK_FLEECA', 'Fleeca Bank'},
	["dealership"] 	= {'CHAR_CARSITE', 'CHAR_CARSITE', 'Legendary Motors'},
	["emergency"] 	= {'CHAR_CALL911', 'CHAR_CALL911', 'Emergency Services'},
	["gopostal"] 	= {'custom_adverts', 'gopostal', 'GoPostal'},
	["gov"] 		= {'char_ls_tourist_board', 'char_ls_tourist_board', 'LS Tourist Board'},
	["lsc"] 		= {'CHAR_LS_CUSTOMS', 'CHAR_LS_CUSTOMS', 'LS Customs'},
	["pegasus"] 	= {'CHAR_PEGASUS_DELIVERY', 'CHAR_PEGASUS_DELIVERY', 'Pegasus Specialties'},
	["social"] 		= {'CHAR_LIFEINVADER', 'CHAR_LIFEINVADER', 'Life Invader' , 'Notification'},
	["strip"] 		= {'char_mp_stripclub_pr', 'char_mp_stripclub_pr', 'Vanilla Unicorn'},
	["taxi"] 		= {'CHAR_TAXI', 'CHAR_TAXI', 'Taxi'},
	["tequilala"] 	= {'CHAR_PROPERTY_BAR_TEQUILALA', 'CHAR_PROPERTY_BAR_TEQUILALA', 'Tequilala'},
	["mors"] 		= {'custom_adverts', 'mors', 'Mors Mutual Insurance'},
	["traffic"] 	= {'custom_adverts', 'transit', 'Traffic Advisory', 'Notification'},
}

Config.AdCooldownMinutes = 1 -- Minutes