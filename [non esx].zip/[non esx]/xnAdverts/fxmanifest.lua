fx_version 'adamant'
games { 'gta5' }

client_scripts {
	'config.lua',
	'client.lua'
}	
	
server_script 'server.lua'