-- Toggle Ragdoll via key (U) written by JAF
-- Made for www.lacountyrp.com
-- Version 1.0.1

-- Add a client script 
client_script 'client.lua'