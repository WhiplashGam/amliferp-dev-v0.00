Config = {}


Config.Vehicles = {
    {Label = "CVPI-Patrol", Hash = "police"},
    {Label = "Doge Chargeur-Patrol", Hash = "police2"},
    {Label = "Ford Interceptor-Patrol", Hash = "police3"},
}