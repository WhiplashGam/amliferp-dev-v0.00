FXServer NEW_BANKING

NOTICE: If you edit this script, I will not provide support. I will only provide support for this script in it's unedited state.

[REQUIREMENTS]

Dependencies For Full Functionality

es_extended => https://github.com/ESX-Org/es_extended



Install To resources/[esx]/new_banking << MUST BE INSTALLED HERE


Add this in your server.cfg :
start new_banking

Credits: Script Created By: @onlyserenity(amjedcha)

Licensing: Please do not edit the background picture of the tablet or post it anywhere else claiming it's yours without @onlyserenity's permission.
